"""Zadania wiedzy o roslinach:
- 'plants_sync'  : rejestr roslin z Kwiatownika + nowe rosliny wykryte w skladnikach przepisow (LLM),
- 'plant_research': dla kazdej rosliny: Wikipedia (kilka jezykow) + strony z innych krajow + ciekawostki
  zebrane wczesniej -> LLM wyciaga informacje z cytatami -> kontrola cytatow -> weryfikacja drugim modelem
  -> kopia pliku rosliny -> agregator (uklad sekcji) -> kontrola kopii -> zapis do Kwiatownika (z kopia zapasowa),
- 'plant_organize': ponowne uporzadkowanie wiedzy juz zapisanej w plikach (bez nowego zbierania),
- 'plant_merge'   : scalenie wiedzy z sieci z rozdzialami pliku rosliny (blok "scalone", Bielik -> inne modele),
- 'plant_place'   : rozmieszczenie punktow, ktore scalanie zostawilo poza tekstem, w konkretnych miejscach strony
  (blok "rozmieszczenie": istniejace i nowe podrozdzialy z "Ukladu strony", app/knowledge/placement.py).
Zbieranie skupia sie na LUKACH: podrozdzialy schematu bez tresci (app/knowledge/schema.py) -> zapytania
w wielu jezykach, takze chinskim i japonskim (app/knowledge/gaps.py), z historia zapytan (PlantQuery).
"""
import asyncio
import copy
import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

from sqlmodel import Session, col, func, select

from app.config import settings
from app.db import engine
from app.knowledge import gaps as gapmod
from app.knowledge import gate, merge, novelty, organize, photos, placement, plantfile, schema
from app.knowledge.extract import extract_facts
from app.knowledge.quotes import finish_facts, supported_label, translate_quotes
from app.mt.nllb import get_translator
from app.knowledge.registry import discover_new_plants, sync_kwiatownik
from app.knowledge.sections import fingerprint, norm_text, similar
from app.knowledge.verify import BATCH, verify_facts
from app.knowledge.wiki import WikiClient
from app.llm.router import AllModelsFailedError
from app.models import Item, ItemKind, Job, JobStatus, Plant, PlantAlias, PlantFact, PlantQuery, SourceRead
from app.worker import activity, snapshots
from app.worker.jobs import job_log
from app.worker.runner import JobRunner

# slowa do szukania ludowych zastosowan rosliny w roznych jezykach (strony spoza Wikipedii)
FOLK_WORDS = {"pl": "medycyna ludowa zastosowanie", "uk": "народна медицина застосування",
              "ru": "народная медицина применение", "de": "Volksmedizin Verwendung",
              "fr": "médecine populaire utilisation", "cs": "lidové léčitelství použití",
              "lt": "liaudies medicina", "sk": "ľudové liečiteľstvo", "hu": "népi gyógyászat",
              "ro": "medicina populară", "bg": "народна медицина", "it": "medicina popolare usi",
              "es": "medicina popular usos", "en": "folk medicine traditional uses"}
_BUSY: set[str] = set()   # rosliny opracowywane teraz (zeby dwa zadania nie badaly tej samej naraz)
SKIP_DOMAINS = ("wikipedia.org", "wikimedia.org", "wikidata.org", "youtube.com", "facebook.com", "instagram.com",
                "pinterest.", "amazon.", "allegro.", "ebay.", "aliexpress.",
                # sklepy i katalogi chemikaliow (wyniki zapytan zh/ja) - nie zrodla wiedzy zielarskiej
                "chemicalbook.", "alibaba.", "1688.com", "made-in-china.", "taobao.", "tmall.", "jd.com",
                "rakuten.", "mercari.", "yahoo.co.jp/auction", "shopping.", "zhihu.com/market")


def _save_stats(job_id: int, stats: dict) -> None:
    with Session(engine) as s:
        job = s.get(Job, job_id)
        job.stats_json = json.dumps(stats)
        s.add(job)
        s.commit()


def _progress(job_id: int, done: int, total: int) -> None:
    with Session(engine) as s:
        job = s.get(Job, job_id)
        job.progress, job.total = done, total
        s.add(job)
        s.commit()


# ============================================================ rejestr
async def run_plants_sync(job_id: int, runner: JobRunner, llm=None) -> dict:
    log = lambda m: job_log(job_id, m)  # noqa: E731
    with Session(engine) as s:
        added = sync_kwiatownik(s, settings.kwiatownik_plants_dir)
        total = s.exec(select(func.count()).select_from(Plant)).one()
    log(f"Rosliny z Kwiatownika: {total} w rejestrze ({added} nowych wpisow)")
    created: list[str] = []
    wiki = WikiClient(settings.user_agent)
    try:
        with Session(engine) as s:
            activity.set(job_id, "rozpoznaje rosliny w skladnikach przepisow (Wikipedia + Wikidata)")
            try:
                created = await discover_new_plants(s, llm, log_fn=log, wiki=wiki)
            except AllModelsFailedError as exc:
                log(f"Modele maja limit - rozpoznawanie skladnikow przerwane ({str(exc)[:120]})")
    finally:
        await wiki.aclose()
    log(f"Nowe rosliny z przepisow: {len(created)}" + (f" ({', '.join(created[:15])})" if created else ""))
    with Session(engine) as s:
        ids = list(s.exec(select(Plant.id)).all())
    for pid in ids:                                    # pokrycie schematu (widok Rosliny, kolejnosc skanow)
        try:
            update_coverage(pid)
        except (OSError, ValueError) as exc:
            log(f"  pokrycie {pid}: {str(exc)[:80]}")
    stats = {"plants": total, "added_from_kwiatownik": added, "new_from_recipes": len(created)}
    _save_stats(job_id, stats)
    return stats


# ============================================================ zbieranie wiedzy
def facts_dump(plant_id: str) -> str:
    """Wszystkie informacje o roslinie w bazie Siedziby (do podgladu "przed/po" w zakladce "Na zywo")."""
    with Session(engine) as s:
        rows = s.exec(select(PlantFact).where(PlantFact.plant_id == plant_id).order_by(PlantFact.id)).all()
        data = [{"id": r.id, "status": r.status, "sekcja": r.section, "czesc": r.part, "tekst": r.text,
                 "cytat": r.quote, "zrodlo": r.source_name or r.source_url, "url": r.source_url, "jezyk": r.language,
                 "powod": r.reason, "wyciagnal": r.extracted_by, "zweryfikowal": r.verified_by} for r in rows]
    return json.dumps({k: v for k, v in [("roslina", plant_id), ("informacje", data)]}, ensure_ascii=False, indent=2) + "\n"


def _record_facts(plant_id: str, title: str, before: str, operation: str) -> None:
    snapshots.record(f"baza Siedziby: wiedza o roslinie {plant_id}", before, facts_dump(plant_id),
                     f"{operation}: {title}", file=f"informacje o roslinie - {title}", link=f"/plants/{plant_id}")


def _known_texts(plant_id: str, file_data: dict | None) -> list[str]:
    with Session(engine) as s:
        texts = list(s.exec(select(PlantFact.text).where(PlantFact.plant_id == plant_id,
                                                          PlantFact.status != "rejected")).all())
    if file_data:
        for key in ("opis", "ostrzezenia", "interakcje"):
            if isinstance(file_data.get(key), str):
                texts.append(file_data[key])
        texts += [c for c in (file_data.get("ciekawostki") or []) if isinstance(c, str)]
    return texts


def _store_facts(plant_id: str, facts, src_url: str, src_name: str, lang: str, model: str,
                 status: str = "new") -> int:
    """Zapis nowych informacji (bez powtorzen: ten sam odcisk, ten sam cytat albo bardzo podobne zdanie).
    status "untranslated" = tekst to jeszcze cytat w oryginale (tlumacz niedostepny) - translate_pending_facts."""
    added = 0
    with Session(engine) as s:
        existing = s.exec(select(PlantFact.fingerprint, PlantFact.text, PlantFact.quote)
                          .where(PlantFact.plant_id == plant_id)).all()
        prints = {fp for fp, _, _ in existing}
        texts = [t for _, t, _ in existing]
        quotes = {norm_text(q) for _, _, q in existing if q}
        new_rows = []
        for f in facts:
            fp = fingerprint(plant_id, f.text)
            if fp in prints or norm_text(f.quote or "") in quotes or any(similar(f.text, t) >= 0.6 for t in texts):
                continue
            row = PlantFact(plant_id=plant_id, section=f.section, part=f.part, text=f.text, quote=f.quote,
                            source_url=src_url, source_name=src_name, language=lang, fingerprint=fp,
                            extracted_by=model, status=status, translated_by=getattr(f, "translated_by", None))
            s.add(row)
            new_rows.append(row)
            prints.add(fp)
            texts.append(f.text)
            quotes.add(norm_text(f.quote or ""))
            added += 1
        s.commit()
        ids = [r.id for r in new_rows if r.status == "new"]
    if ids:
        from app.nn.hooks import review_facts
        review_facts(ids, model)        # siec sprawdza sekcje i czesc rosliny (tryb ustawiany w /nn)
    return added


async def translate_pending_facts(log, limit: int | None = None, plant_ids: list[str] | None = None) -> dict:
    """Tlumaczenie maszynowe cytatow (bez LLM): najpierw informacje czekajace na tlumacza ("untranslated"),
    potem dawne informacje z tekstem napisanym przez LLM (translated_by=None) - ich tekst zastepuje tlumaczenie
    cytatu. Zapisane juz w plikach (applied) wracaja do "verified", zeby zapis wiedzy podmienil tekst w pliku.
    Tlumacz niedostepny / budzet DeepL na wiedze wyczerpany -> koniec, reszta nastepnym razem."""
    limit = settings.knowledge_retranslate_per_run if limit is None else limit
    stats = {"translated": 0, "old_replaced": 0, "rejected": 0, "waiting": 0}
    if limit <= 0:
        return stats
    mt = get_translator()
    with Session(engine) as s:
        q = select(PlantFact).where(col(PlantFact.quote).is_not(None))
        if plant_ids:
            q = q.where(col(PlantFact.plant_id).in_(plant_ids))
        pending = s.exec(q.where(PlantFact.status == "untranslated").order_by(PlantFact.id).limit(limit)).all()
        old = s.exec(q.where(col(PlantFact.translated_by).is_(None),
                             col(PlantFact.status).in_(["new", "verified", "applied"]))
                     .order_by(PlantFact.id).limit(max(0, limit - len(pending)))).all()
        rows = list(pending) + list(old)
        for r in rows:
            s.expunge(r)
    if not rows:
        return stats
    results = await asyncio.to_thread(translate_quotes, mt, [(r.language or "", r.quote) for r in rows])
    with Session(engine) as s:
        for r, (pl, why, engine_name) in zip(rows, results):
            row = s.get(PlantFact, r.id)
            if row is None:
                continue
            if pl is None and why.startswith("brak tlumacza"):
                stats["waiting"] += 1
                continue
            if pl is None or not (12 <= len(pl) <= 700):
                stats["rejected"] += 1
                if row.status == "untranslated":
                    row.status, row.reason = "rejected", (why or "dlugosc tlumaczenia")[:300]
                else:
                    row.translated_by = "kontrola"        # zostaje stary tekst; nie probujemy ponownie
                    row.reason = ((row.reason + "; ") if row.reason else "") + (why or "dlugosc")[:150]
                s.add(row)
                continue
            was = row.status
            row.text, row.translated_by = pl, engine_name or "mt"
            row.fingerprint = fingerprint(row.plant_id, pl)
            if row.section == "magia" and row.meta_json:
                try:
                    meta = json.loads(row.meta_json)
                    for key in ("kraj", "epoka", "tradycja"):
                        if key in meta and not supported_label(meta[key], pl):
                            meta.pop(key)
                    row.meta_json = json.dumps(meta, ensure_ascii=False) if meta else None
                except ValueError:
                    pass
            if was == "untranslated":
                row.status = "new"
                stats["translated"] += 1
            else:
                stats["old_replaced"] += 1
                if was == "applied":
                    row.status = "verified"               # zapis wiedzy podmieni tekst w pliku rosliny
            s.add(row)
        s.commit()
    if any(stats.values()):
        log("Tlumaczenie cytatow wiedzy (bez LLM): "
            f"czekajace {stats['translated']}, dawne teksty LLM zastapione {stats['old_replaced']}, "
            f"odrzucone {stats['rejected']}" + (f", nadal czeka {stats['waiting']} (tlumacz/budzet)" if stats["waiting"] else ""))
    return stats


def _names(plant: Plant) -> dict[str, str]:
    try:
        labels = json.loads(plant.names_json) if plant.names_json else {}
        titles = json.loads(plant.wiki_titles_json) if plant.wiki_titles_json else {}
    except ValueError:
        labels, titles = {}, {}
    return gapmod.plant_names(plant.nazwa_lat, plant.nazwa_pl, labels, titles)


def _name_keys(plant: Plant) -> list[str]:
    """Nazwy rosliny do szukania w tekstach stron: polska, lacinska (i sam gatunek), nazwy z Wikidata we wszystkich
    jezykach (zh, ja, uk...) i aliasy (np. dawne id pliku)."""
    keys = {plant.nazwa_pl, plant.nazwa_lat, " ".join((plant.nazwa_lat or "").split()[:2])}
    first = (plant.nazwa_pl or "").split()[0].lower() if plant.nazwa_pl else ""
    if len(first) >= 6:                                # rdzen polskiej nazwy: rumianek/rumianku -> "rumian"
        keys.add(first[:-2])
    for v in _names(plant).values():
        keys.update(v if isinstance(v, (list, tuple, set)) else [v])
    with Session(engine) as s:
        keys.update(a.name for a in s.exec(select(PlantAlias).where(PlantAlias.plant_id == plant.id)).all())
    return sorted({str(k).strip().lower() for k in keys if k and len(str(k).strip()) >= 3}, key=len, reverse=True)


def fact_pages_for(plant: Plant, limit: int = 3) -> list:
    """Strony z ciekawostkami juz pobrane przez skaner (Item kind=fact), ktore mowia o tej roslinie (R11).
    Najpierw te, ktore wymieniaja ja najczesciej; strony juz wykorzystane dla tej rosliny sa pomijane, wiec przy
    kazdym zbieraniu dochodza nowe (wczesniej co raz te same 3 pierwsze z bazy)."""
    if limit <= 0:
        return []
    keys = _name_keys(plant)
    if not keys:
        return []
    with Session(engine) as s:
        used = set(s.exec(select(PlantFact.source_url).where(PlantFact.plant_id == plant.id)).all())
        rows = s.exec(select(Item).where(Item.kind == ItemKind.fact, col(Item.raw_text).is_not(None))).all()
        for it in rows:
            s.expunge(it)
    scored = []
    for it in rows:
        if it.url in used:
            continue
        low = (it.raw_text or "").lower()
        hits = sum(low.count(k) for k in keys)
        if hits:
            scored.append((hits, it.id, it))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [it for _, _, it in scored[:limit]]


def _seen_paragraphs(plant_id: str, url: str) -> set[str]:
    with Session(engine) as s:
        row = s.exec(select(SourceRead).where(SourceRead.plant_id == plant_id, SourceRead.url == url)).first()
    return novelty.loads(row.paragraphs_json) if row else set()


def _remember_read(plant_id: str, url: str, done: list[str], facts: int) -> None:
    """Zapamietuje akapity zrodla przeczytane dla tej rosliny (etap 2: filtr nowosci)."""
    now = datetime.now(timezone.utc)
    with Session(engine) as s:
        row = s.exec(select(SourceRead).where(SourceRead.plant_id == plant_id, SourceRead.url == url)).first()
        if row is None:
            row = SourceRead(plant_id=plant_id, url=url)
        seen = novelty.loads(row.paragraphs_json) | set(done)
        row.paragraphs_json = json.dumps(sorted(seen))
        row.reads = (row.reads or 0) + 1
        row.facts = (row.facts or 0) + facts
        row.last_at = now
        s.add(row)
        s.commit()


def closed_gaps(plant_id: str, now: datetime | None = None) -> set[str]:
    """Luki (podrozdzialy), o ktore pytano KNOWLEDGE_GAP_CLOSE_QUERIES razy w ostatnich KNOWLEDGE_GAP_CLOSE_DAYS
    dniach i zadne zapytanie nie dalo informacji - "brak w zrodlach", nie pytamy przez ten czas (np. "Kosmetyka"
    wracala przy prawie kazdej roslinie: 150 zapytan, 15 trafien)."""
    n = settings.knowledge_gap_close_queries
    if n <= 0:
        return set()
    since = (now or datetime.now(timezone.utc)) - timedelta(days=settings.knowledge_gap_close_days)
    with Session(engine) as s:
        rows = s.exec(select(PlantQuery).where(PlantQuery.plant_id == plant_id,
                                               col(PlantQuery.slot).not_like("enc:%"))).all()
    asked: dict[str, int] = {}
    useful: set[str] = set()
    for q in rows:
        at = q.created_at if q.created_at.tzinfo else q.created_at.replace(tzinfo=timezone.utc)
        if at < since:
            continue
        asked[q.slot] = asked.get(q.slot, 0) + 1
        if (q.facts or 0) > 0:
            useful.add(q.slot)
    return {slot for slot, k in asked.items() if k >= n and slot not in useful}


def useless_encyclopedias() -> set[str]:
    """Encyklopedie, ktore po KNOWLEDGE_ENC_OFF_QUERIES zapytaniach (wszystkie rosliny) nie daly zadnej informacji
    (diagnoza: mpdb, duke, iplant, a-hospital - 70 zapytan, 0 informacji)."""
    n = settings.knowledge_enc_off_queries
    if n <= 0:
        return set()
    with Session(engine) as s:
        rows = s.exec(select(PlantQuery.slot, func.count(), func.sum(PlantQuery.facts))
                      .where(col(PlantQuery.slot).like("enc:%")).group_by(PlantQuery.slot)).all()
    return {slot.split(":", 1)[1] for slot, k, f in rows if k >= n and not (f or 0)}


def _low_yield_days() -> list[int]:
    try:
        return [int(x) for x in settings.knowledge_low_yield_days.split(",") if x.strip()]
    except ValueError:
        return [7, 14, 30]


def note_yield(plant_id: str, facts: int, now: datetime | None = None) -> datetime | None:
    """Malejacy zwrot: po 2 badaniach z rzedu z < 2 informacjami nastepne najwczesniej po 7, potem 14, potem 30 dniach.
    Badanie z wynikiem kasuje przerwe. Zwraca termin nastepnego badania (albo None)."""
    now = now or datetime.now(timezone.utc)
    days = _low_yield_days()
    with Session(engine) as s:
        row = s.get(Plant, plant_id)
        if row is None:
            return None
        if facts >= 2:
            row.low_yield_runs, row.research_after = 0, None
        else:
            row.low_yield_runs = (row.low_yield_runs or 0) + 1
            k = row.low_yield_runs - 2
            row.research_after = now + timedelta(days=days[min(k, len(days) - 1)]) if k >= 0 and days else None
        s.add(row)
        s.commit()
        return row.research_after


def research_paused(plant: Plant, now: datetime | None = None) -> datetime | None:
    at = plant.research_after
    if at is None:
        return None
    at = at if at.tzinfo else at.replace(tzinfo=timezone.utc)
    return at if at > (now or datetime.now(timezone.utc)) else None


def _recent_queries(plant_id: str) -> tuple[set[str], set[str]]:
    """(zapytania zadane w ostatnich KNOWLEDGE_REQUERY_DAYS dniach, adresy juz uzyte dla tej rosliny)."""
    since = datetime.now(timezone.utc) - timedelta(days=settings.knowledge_requery_days)
    with Session(engine) as s:
        rows = s.exec(select(PlantQuery).where(PlantQuery.plant_id == plant_id)).all()
        urls = set(s.exec(select(PlantFact.source_url).where(PlantFact.plant_id == plant_id)).all())
    done = set()
    for q in rows:
        at = q.created_at if q.created_at.tzinfo else q.created_at.replace(tzinfo=timezone.utc)
        if at >= since:
            done.add(q.query)
        if q.used_url:
            urls.add(q.used_url)
    return done, urls


def _log_query(plant_id: str, gq, results: int, used_url: str | None) -> int:
    with Session(engine) as s:
        row = PlantQuery(plant_id=plant_id, slot=gq.gap.path, language=gq.lang, query=gq.query, results=results,
                         used_url=used_url)
        s.add(row)
        s.commit()
        return row.id


def _query_facts(qid: int, n: int) -> None:
    with Session(engine) as s:
        row = s.get(PlantQuery, qid)
        if row:
            row.facts = n
            s.add(row)
            s.commit()


async def _web_sources(plant: Plant, log, file_data: dict | None = None, slots: list[str] | None = None) -> list[tuple]:
    """(url, nazwa, jezyk, tekst, luki, id_zapytania) z innych stron: ciekawostki juz zebrane przez Siedzibe
    + wyszukiwarka skupiona na LUKACH rosliny (czego brakuje w schemacie) w wielu jezykach, takze zh/ja."""
    out: list[tuple] = [(it.url, urlparse(it.url).netloc, it.language or "?", (it.raw_text or "")[:8000], None, None)
                        for it in fact_pages_for(plant, limit=settings.knowledge_fact_pages)]
    if settings.knowledge_web_pages <= 0 or not plant.nazwa_lat:
        return out
    from app.discovery.search import search_all
    from app.scrapers.fetcher import Fetcher
    from app.scrapers.page import parse_page
    from app.worker.discover import build_backends
    backends = build_backends()
    if not backends:
        return out
    cov = coverage_for(plant.id, file_data)
    gaps = gapmod.find_gaps(file_data, cov["sloty"])
    if slots:                                          # szukanie konkretnych podrozdzialow (z panelu)
        wanted = [g for g in gaps if g.path in slots or any(g.path.startswith(x + ".") for x in slots)]
        gaps = wanted or [gapmod.Gap(x, (schema.SLOT_BY_PATH[x].title if x in schema.SLOT_BY_PATH else x),
                                     gapmod.SLOT_TOPIC.get(x, "lecznicze")) for x in slots]
    closed = closed_gaps(plant.id)
    if closed and not slots:
        shut = [g for g in gaps if g.path in closed]
        gaps = [g for g in gaps if g.path not in closed]
        if shut:
            log(f"  luki bez wynikow w zrodlach (nie pytam przez {settings.knowledge_gap_close_days} dni): "
                + ", ".join(g.title for g in shut[:6]))
            if not gaps:
                return out
    if not gaps:
        log("  luki: brak - wszystkie podrozdzialy maja tresc; szukam ogolnie")
        gaps = [gapmod.Gap("zastosowanie.medyczne", "Praktyczne zastosowanie - Medycyna", "lecznicze"),
                gapmod.Gap("ciekawostki", "Wiedza tajemna - Ciekawostki", "folklor")]
    names = _names(plant)
    langs = [x.strip() for x in settings.knowledge_search_langs.split(",") if x.strip()]
    done, used_urls = _recent_queries(plant.id)
    queries = gapmod.build_queries(gaps, names, langs, done, max_gaps=settings.knowledge_gap_slots)
    log(f"  luki ({len(gaps)}): " + ", ".join(g.title for g in gaps[:6]) + ("..." if len(gaps) > 6 else ""))
    if not queries:
        log("  wszystkie zapytania o luki byly zadane niedawno - pomijam wyszukiwarke")
        return out
    fetcher = Fetcher(settings.user_agent, settings.request_delay_s,
                      accept_language="pl,en;q=0.8,de;q=0.6,zh;q=0.5,ja;q=0.5,*;q=0.3")
    found = 0
    topics_done: set[str] = set()
    try:
        for gq in queries:
            if found >= settings.knowledge_web_pages:
                break
            if gq.gap.topic in topics_done:            # temat juz ma strone - nastepna luka
                continue
            results = await search_all(backends, gq.query, gq.lang, "", log_fn=log)
            used = None
            for r in results[:6]:
                if any(d in r.url for d in SKIP_DOMAINS) or r.url in used_urls or any(r.url == o[0] for o in out):
                    continue
                res = await fetcher.get(r.url)
                if not res.ok:
                    continue
                page = await asyncio.to_thread(parse_page, res.text, res.url)
                min_len = 300 if gq.lang in ("zh", "ja") else 800
                if len(page.text) < min_len or not gapmod.page_about_plant(page.text, names, gq.lang):
                    continue
                used = res.url
                focus = gapmod.gaps_for_focus(gaps, gq.gap.topic)
                qid = _log_query(plant.id, gq, len(results), used)
                out.append((res.url, urlparse(res.url).netloc, page.lang or gq.lang, page.text[:8000], focus, qid))
                found += 1
                topics_done.add(gq.gap.topic)
                log(f"  [{gq.lang}] {gq.gap.title}: {urlparse(res.url).netloc}")
                break
            if used is None:
                _log_query(plant.id, gq, len(results), None)
    finally:
        await fetcher.aclose()
    return out


def _recent_encyclopedias(plant_id: str) -> set[str]:
    """Encyklopedie pytane o te rosline w ostatnich KNOWLEDGE_REQUERY_DAYS dniach (z wynikiem albo bez)."""
    since = datetime.now(timezone.utc) - timedelta(days=settings.knowledge_requery_days)
    with Session(engine) as s:
        rows = s.exec(select(PlantQuery).where(PlantQuery.plant_id == plant_id,
                                               col(PlantQuery.slot).startswith("enc:"))).all()
    out = set()
    for q in rows:
        at = q.created_at if q.created_at.tzinfo else q.created_at.replace(tzinfo=timezone.utc)
        if at >= since:
            out.add(q.slot.split(":", 1)[1])
    return out


async def _encyclopedia_sources(plant: Plant, log, file_data: dict | None = None, job_id: int = 0) -> list[tuple]:
    """Zagraniczne encyklopedie i bazy (Kotobank, Baidu Baike, Encyklopedia Kultury Koreanskiej, PFAF...):
    kilka na przebieg, rotacyjnie - kolejne przebiegi siegaja po kolejne zrodla."""
    if not settings.knowledge_encyclopedias or settings.knowledge_enc_max <= 0:
        return []
    from app.knowledge import encyclopedias as encmod
    from app.scrapers.fetcher import Fetcher
    from app.worker.discover import build_backends
    names = _names(plant)
    cov = coverage_for(plant.id, file_data)
    gaps = gapmod.find_gaps(file_data, cov["sloty"])
    topics = list(dict.fromkeys(g.topic for g in gaps)) or ["lecznicze", "folklor"]
    _, used_urls = _recent_queries(plant.id)
    recent = _recent_encyclopedias(plant.id)
    off = useless_encyclopedias()                       # 0 informacji po wielu zapytaniach - pomijane
    used_domains = {urlparse(u).netloc for u in used_urls}
    picks = [e for e in encmod.choose(names, topics, used_domains, settings.knowledge_enc_max + len(recent) + len(off))
             if e.key not in recent and e.key not in off][:settings.knowledge_enc_max]
    if not picks:
        log("  encyklopedie: wszystkie dostepne byly pytane niedawno (albo brak nazw w ich jezykach)")
        return []
    fetcher = Fetcher(settings.user_agent, settings.request_delay_s,
                      accept_language="ja,zh;q=0.9,ko;q=0.8,en;q=0.7,*;q=0.3")
    backends = build_backends()
    out: list[tuple] = []
    try:
        for enc in picks:
            if job_id:
                activity.set(job_id, f"{plant.nazwa_pl}: encyklopedia", enc.name)
            f = await encmod.fetch(enc, names, fetcher, backends, used_urls, log)
            with Session(engine) as s:
                q = PlantQuery(plant_id=plant.id, slot=f"enc:{enc.key}", language=enc.lang,
                               query=f"{encmod.plant_name(enc, names) or ''} @ {enc.domain}"[:300],
                               results=1 if f.url else 0, used_url=f.url)
                s.add(q)
                s.commit()
                qid = q.id
            if not f.url:
                log(f"  [{enc.country}] {enc.name}: brak ({f.reason[:120]})")
                continue
            topic = next((t for t in topics if t in enc.topics), None)
            out.append((f.url, enc.name, enc.lang, f.text[:10000], gapmod.gaps_for_focus(gaps, topic) if gaps else None,
                        qid))
            log(f"  [{enc.country}] {enc.name}: {f.url} ({f.how})")
    finally:
        await fetcher.aclose()
    return out


async def research_plant(plant_id: str, llm, wiki: WikiClient, log, job_id: int = 0,
                         slots: list[str] | None = None) -> dict:
    """Zbiera informacje o jednej roslinie (bez zapisu do pliku). Zwraca statystyki."""
    stats = {"sources": 0, "facts": 0, "rejected_quotes": 0}
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        s.expunge(plant)
    file_data, _ = plantfile.read_plant(settings.kwiatownik_plants_dir, plant_id)
    known = _known_texts(plant_id, file_data)
    sources: list[tuple[str, str, str, str]] = []

    # --- Wikipedia (przez Wikidata: jeden gatunek, wiele jezykow)
    try:
        wp = await wiki.find_plant(plant.nazwa_lat, plant.nazwa_pl)
    except Exception as exc:
        log(f"  Wikidata niedostepna: {str(exc)[:100]}")
        wp = None
    if wp:
        with Session(engine) as s:
            row = s.get(Plant, plant_id)
            row.wikidata, row.wiki_titles_json = wp.qid, json.dumps(wp.titles, ensure_ascii=False)
            if wp.labels:
                row.names_json = json.dumps(wp.labels, ensure_ascii=False)
            if wp.aliases:
                row.aliases_json = json.dumps(wp.aliases, ensure_ascii=False)
            row.names_checked_at = datetime.now(timezone.utc)
            if not row.nazwa_lat and wp.taxon:
                row.nazwa_lat = wp.taxon
            s.add(row)
            s.commit()
        if settings.knowledge_photos:
            await collect_photos(plant_id, wp, wiki, log, file_data)
        langs = [x.strip() for x in settings.knowledge_languages.split(",") if x.strip() in wp.titles]
        langs = langs[:settings.knowledge_wiki_langs]
        langs += [x.strip() for x in settings.knowledge_asia_langs.split(",")       # chinska / japonska Wikipedia
                  if x.strip() in wp.titles and x.strip() not in langs]
        for lang in langs:
            try:
                art = await wiki.article(lang, wp.titles[lang])
            except Exception as exc:                   # jedna wersja jezykowa niedostepna - reszta dalej
                log(f"  Wikipedia ({lang}): {str(exc)[:100]}")
                continue
            if art:
                sources.append((art.url, f"Wikipedia ({lang}): {art.title}", lang, art.text, None, None))
        log(f"  Wikipedia: {wp.qid}, artykuly: {', '.join(src[2] for src in sources) or 'brak'}")
    else:
        log("  Wikipedia: nie znaleziono gatunku w Wikidata")
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        s.expunge(plant)
    enc_urls: set[str] = set()
    if not slots:                                      # szukanie konkretnych podrozdzialow = tylko wyszukiwarka
        enc = await _encyclopedia_sources(plant, log, file_data, job_id)
        enc_urls = {src[0] for src in enc}
        sources += enc
    sources += await _web_sources(plant, log, file_data, slots)

    # strony "o roslinie" (artykul Wikipedii, haslo encyklopedii) - caly nowy tekst; strony ogolne (wyszukiwarka,
    # ciekawostki ze skanera) - tylko akapity z nazwa rosliny
    about = {src[0] for src in sources if src[1].startswith("Wikipedia (")} | enc_urls
    keys = _name_keys(plant)
    for k, (url, name, lang, text, focus, qid) in enumerate(sources, 1):
        nv = novelty.select_new(text, _seen_paragraphs(plant_id, url), None if url in about else keys,
                                settings.knowledge_min_new_chars)
        if nv.why_skip:                                  # etap 2: nic nowego - bez wywolania LLM
            stats["skipped"] = stats.get("skipped", 0) + 1
            if nv.done:
                _remember_read(plant_id, url, nv.done, 0)
            log(f"  {name}: pominiete bez LLM ({nv.why_skip})")
            continue
        if nv.seen or len(nv.text) < len(text) * 0.9:
            log(f"  {name}: do LLM {len(nv.text)} z {len(text)} znakow (przeczytane wczesniej: {nv.seen}/{nv.total} "
                f"akapitow{', nie o tej roslinie: ' + str(nv.off_topic) if nv.off_topic else ''})")
        if job_id:
            activity.set(job_id, f"{plant.nazwa_pl}: zrodlo {k}/{len(sources)} - LLM wyciaga informacje", name)
        try:
            facts, rejected, model = await extract_facts(llm, plant.nazwa_pl, plant.nazwa_lat, name, lang, nv.text,
                                                         known, focus)
        except AllModelsFailedError:
            raise
        except Exception as exc:                       # zly JSON jednego zrodla nie zatrzymuje reszty
            log(f"  [blad] {name}: {str(exc)[:120]}")
            continue
        # tekst po polsku = tlumaczenie maszynowe doslownego cytatu (bez LLM), po kontroli
        ready, pending, rej_mt = await asyncio.to_thread(finish_facts, facts, lang, get_translator())
        added = _store_facts(plant_id, ready, url, name, lang, model)
        waiting = _store_facts(plant_id, pending, url, name, lang, model, status="untranslated")
        _remember_read(plant_id, url, nv.done, added + waiting)
        if qid:
            _query_facts(qid, added + waiting)
        known += [f.text for f in ready]
        stats["sources"] += 1
        stats["facts"] += added
        stats["untranslated"] = stats.get("untranslated", 0) + waiting
        stats["rejected_quotes"] += len(rejected) + len(rej_mt)
        log(f"  {name}: {added} nowych informacji"
            + (f", {waiting} czeka na tlumacza" if waiting else "")
            + (f", odrzucono {len(rejected) + len(rej_mt)} (cytat/tlumaczenie)" if rejected or rej_mt else ""))
    return stats


async def verify_plant(plant_id: str, llm, log, job_id: int = 0) -> dict:
    """Weryfikacja nowych informacji drugim modelem (innym niz ten, ktory je wyciagnal)."""
    stats = {"verified": 0, "rejected": 0}
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        facts = s.exec(select(PlantFact).where(PlantFact.plant_id == plant_id, PlantFact.status == "new")).all()
        for f in facts:
            s.expunge(f)
        name, lat = plant.nazwa_pl, plant.nazwa_lat
    size = max(1, settings.verify_batch or BATCH)        # R8: wieksze paczki = mniej wywolan i limitow 429
    for i in range(0, len(facts), size):
        batch = facts[i:i + size]
        if job_id:
            activity.set(job_id, f"{name}: weryfikacja drugim modelem", f"informacje {i + 1}-{i + len(batch)} z {len(facts)}")
        avoid = {(f.extracted_by or "").replace("/", ":", 1) for f in batch if f.extracted_by}
        verdicts, model = await verify_facts(llm, name, lat, batch, avoid=avoid)
        with Session(engine) as s:
            for f in batch:
                if f.id not in verdicts:
                    continue
                ok, why = verdicts[f.id]
                row = s.get(PlantFact, f.id)
                row.status, row.reason, row.verified_by = ("verified" if ok else "rejected"), why or None, model
                s.add(row)
                stats["verified" if ok else "rejected"] += 1
            s.commit()
    if facts:
        log(f"  weryfikacja: potwierdzone {stats['verified']}, odrzucone {stats['rejected']}")
    return stats


async def _organized(cand: dict, name: str, latin: str | None, llm, log) -> dict:
    """Agregator: surowe informacje z kopii -> sekcje/punkty/zrodla (LLM + kontrola kodem, inaczej deterministycznie)."""
    facts = cand["wiedza"].get("fakty") or []
    # 2026-11-03: LLM nie redaguje tekstow wiedzy (KNOWLEDGE_LLM_EDITING=false) - uklad deterministyczny
    layout, how = await organize.organize(llm if settings.knowledge_llm_editing else None, name, latin, facts, log)
    points = sum(len(sec["punkty"]) for sec in layout["sekcje"])
    log(f"  agregator ({how}): {len(facts)} informacji -> {points} punktow w {len(layout['sekcje'])} sekcjach")
    return plantfile.with_layout(cand, layout, how)


async def _merged(cand: dict, name: str, latin: str | None, llm, log) -> dict:
    """Scalanie wiedzy z sieci z rozdzialami pliku (blok "scalone"); Bielik 11B -> Bielik 4.5B -> inne modele."""
    from app.worker.ollama_pull import merge_models, missing_ollama_models
    prefer = merge_models()
    try:                                              # Bielik juz jest -> poprawia scalenia zrobione w chmurze
        absent = set(await missing_ollama_models(llm)) if llm is not None else {"?"}
        redo = bool(prefer) and not any(m.split(":", 1)[1] in absent for m in prefer if m.startswith("ollama:"))
    except Exception:
        redo = False
    try:
        sc = await merge.build_merged(llm, cand, name, latin, prefer=prefer, log=log, redo_other_models=redo,
                                      write_with_llm=settings.knowledge_llm_editing,
                                      budget_s=settings.merge_plant_budget_s or None,
                                      prefer_timeout=settings.merge_timeout_s or None)
    except AllModelsFailedError:
        raise
    except Exception as exc:                          # scalanie nie moze zatrzymac zapisu wiedzy
        log(f"  scalanie z rozdzialami: blad ({str(exc)[:120]}) - zostaje poprzednie")
        return await _placed(cand, name, llm, log)
    return await _placed(merge.with_merged(cand, sc), name, llm, log)


def backfill_quotes(cand: dict) -> int:
    """Dopisuje do wiedza.fakty fragmenty zrodel ("cytat") z bazy Siedziby - strona robi z nich link przewijajacy
    do miejsca informacji na stronie zrodla i pokazuje je w dymku zrodla. Zwraca liczbe uzupelnionych."""
    facts = [f for f in ((cand.get("wiedza") or {}).get("fakty") or []) if isinstance(f, dict) and not f.get("cytat")]
    ids = {}
    for f in facts:
        fid = str(f.get("id") or "")
        if fid.startswith("s") and fid[1:].isdigit():
            ids[int(fid[1:])] = f
    if not ids:
        return 0
    with Session(engine) as s:
        rows = s.exec(select(PlantFact.id, PlantFact.quote).where(col(PlantFact.id).in_(list(ids)))).all()
    n = 0
    for fid, quote in rows:
        q = plantfile.quote_snippet(quote)
        if q:
            ids[fid]["cytat"] = q
            n += 1
    return n


async def _placed(cand: dict, name: str, llm, log, force: bool = False) -> dict:
    """Rozmieszczenie punktow niewmontowanych w tekst rozdzialow (blok "rozmieszczenie")."""
    try:
        backfill_quotes(cand)
        blk = await placement.build_placement(llm, cand, name, log=log, force=force)
    except AllModelsFailedError:
        raise
    except Exception as exc:                          # rozmieszczenie nie moze zatrzymac zapisu wiedzy
        log(f"  rozmieszczenie: blad ({str(exc)[:120]}) - zostaje poprzednie")
        return cand
    return placement.with_placement(cand, blk)


def web_section_counts(plant_id: str) -> dict[str, int]:
    """Zweryfikowane/zapisane informacje z sieci wg sekcji (do pokrycia schematu)."""
    with Session(engine) as s:
        rows = s.exec(select(PlantFact.section, func.count()).where(
            PlantFact.plant_id == plant_id, col(PlantFact.status).in_(["verified", "applied"]))
            .group_by(PlantFact.section)).all()
    return dict(rows)


def coverage_for(plant_id: str, data: dict | None = None) -> dict:
    """Pokrycie schematu rosliny: co jest w pliku (recznie / z sieci), czego brakuje."""
    if data is None:
        data, _ = plantfile.read_plant(settings.kwiatownik_plants_dir, plant_id)
    return schema.coverage(data, web_section_counts(plant_id))


def update_coverage(plant_id: str, data: dict | None = None) -> dict:
    cov = coverage_for(plant_id, data)
    with Session(engine) as s:
        row = s.get(Plant, plant_id)
        if row:
            row.coverage, row.gaps_json = cov["procent"], json.dumps(cov["puste"], ensure_ascii=False)
            s.add(row)
            s.commit()
    return cov


def _mark_error(plant_id: str, errors: list[str]) -> None:
    with Session(engine) as s:
        row = s.get(Plant, plant_id)
        row.status, row.note = "error", "; ".join(errors[:3])[:300]
        s.add(row)
        s.commit()


def _photos_of(plant) -> tuple[list[dict], list[dict]]:
    try:
        data = json.loads(plant.photos_json) if plant.photos_json else {}
    except ValueError:
        data = {}
    return data.get("zdjecia") or [], data.get("autorzy") or []


def _gate_skip(pid: str, n: int, total: int, log, out: dict) -> bool:
    """Bezpiecznik bramy zapisu: roslina z powtarzajaca sie odmowa kontroli kopii jest pomijana, dopoki jej plik
    sie nie zmieni - zamiast wydawac czas LLM na wiedze, ktora i tak nie trafi na strone."""
    reason = gate.blocked(pid)
    if not reason:
        return False
    log(f"[{n}/{total}] {pid} - wstrzymana przez bezpiecznik bramy zapisu ({reason[:120]}); czeka na poprawke pliku")
    out["zablokowane"] = out.get("zablokowane", 0) + 1
    return True


def _checkpoint(job_id: int, pid: str) -> None:
    """Punkt kontrolny: roslina skonczona w tym zadaniu. Ponowienie po restarcie (actions.retry_job) ja pomija."""
    with Session(engine) as s:
        job = s.get(Job, job_id)
        if job is None:
            return
        try:
            st = json.loads(job.state_json) if job.state_json else {}
        except ValueError:
            st = {}
        done = st.setdefault("done", [])
        if pid not in done:
            done.append(pid)
            job.state_json = json.dumps(st, ensure_ascii=False)
            s.add(job)
            s.commit()


def _check(plant_id: str, original: dict | None, cand: dict, log) -> list[str]:
    """Brama zapisu: wyrownanie id do nazwy pliku (app/knowledge/gate.py) + kontrola kopii."""
    errors, note = gate.align_identity(cand, plant_id)
    if note:
        log(f"  {note}")
    return errors or plantfile.validate_candidate(original, cand, plant_id)


def _rejected(plant_id: str, original: dict | None, cand: dict, errors: list[str], operation: str, log) -> str:
    """Kopia odrzucona przez kontrole: plik bez zmian, ale migawka "przed/po" pokazuje, co chcielismy zapisac.
    Odmowa trafia do bezpiecznika bramy - po kolejnej z tego samego powodu roslina jest pomijana."""
    trips = gate.record_rejection(plant_id, errors)
    log("  ZABLOKOWANE W BRAMIE ZAPISU (kontrola kopii, plik bez zmian): " + "; ".join(errors[:5])
        + (f" - odmowa {trips}. z rzedu, roslina wstrzymana do zmiany pliku" if trips >= gate.GATE_TRIPS else ""))
    _mark_error(plant_id, errors)
    snapshots.record_dict(plantfile.plant_path(settings.kwiatownik_plants_dir, plant_id), original, cand,
                          f"{operation}: {plant_id}", applied=False, note="; ".join(errors[:20]),
                          link=f"/plants/{plant_id}")
    return "invalid"


def _save_candidate(plant_id: str, original: dict | None, cand: dict, crlf: bool, log, facts=(),
                    operation: str = "dopisanie wiedzy") -> str:
    """Kontrola kopii -> kopia zapasowa -> zapis. Wspolne dla wiedzy i zdjec."""
    errors = _check(plant_id, original, cand, log)
    if errors:
        return _rejected(plant_id, original, cand, errors, operation, log)
    if cand == original:
        return "nothing"
    plants_dir = Path(settings.kwiatownik_plants_dir)
    backup = plantfile.write_plant(plants_dir, plant_id, cand, crlf, Path(settings.backups_dir) / "plants",
                                   operation)
    with Session(engine) as s:
        for f in facts:
            row = s.get(PlantFact, f.id)
            row.status = "applied"
            s.add(row)
        row = s.get(Plant, plant_id)
        if row:
            row.status, row.last_apply_at, row.note = "applied", datetime.now(timezone.utc), None
            s.add(row)
        s.commit()
    gate.record_success(plant_id)
    log(f"  zapisano do Kwiatownika: {plantfile.diff_summary(original, cand)}"
        + (f" (kopia zapasowa: {backup.name})" if backup else ""))
    return "applied"


async def apply_plant(plant_id: str, log, llm=None) -> str:
    """Kopia pliku rosliny + zweryfikowane informacje -> agregator -> zdjecia -> kontrola kopii -> zapis."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        facts = s.exec(select(PlantFact).where(PlantFact.plant_id == plant_id, PlantFact.status == "verified")
                       .order_by(PlantFact.id)).all()
        for f in facts:
            s.expunge(f)
        s.expunge(plant)
    pics, credits = _photos_of(plant)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if not facts and not (original and (pics or credits)):
        return "nothing"
    if original is None:
        applied_before = _count(plant_id, "applied")
        from_wiki = any("wikipedia.org" in f.source_url for f in facts)
        if len(facts) + applied_before < settings.knowledge_min_facts_new or not from_wiki:
            log(f"  plik nowej rosliny poczeka: {len(facts)} informacji"
                + ("" if from_wiki else ", brak potwierdzenia w Wikipedii"))
            return "waiting"
    if facts:
        base = plantfile.skeleton(plant_id, plant.nazwa_pl, plant.nazwa_lat)
        cand = plantfile.build_candidate(original, base, facts)
        cand = await _organized(cand, plant.nazwa_pl, plant.nazwa_lat, llm, log)
        if settings.knowledge_auto_merge:
            cand = await _merged(cand, plant.nazwa_pl, plant.nazwa_lat, llm, log)
    else:
        cand = copy.deepcopy(original)
    cand = plantfile.with_photos(cand, original, pics, credits)
    outcome = _save_candidate(plant_id, original, cand, crlf, log, facts,
                              "dopisanie wiedzy" if facts else "zdjecia")
    if outcome == "applied":
        _after_write(plant_id, cand)
    return outcome


def _after_write(plant_id: str, cand: dict) -> None:
    with Session(engine) as s:
        row = s.get(Plant, plant_id)
        if row and cand.get("scalone"):
            row.last_merge_at = datetime.now(timezone.utc)
            s.add(row)
            s.commit()
    update_coverage(plant_id, cand)


async def collect_photos(plant_id: str, wp, wiki: WikiClient, log, file_data: dict | None = None) -> int:
    """Zdjecia gatunku z Wikipedii/Commons -> Plant.photos_json (do zapisu w pliku przy apply)."""
    langs = [x.strip() for x in settings.knowledge_languages.split(",") if x.strip()]
    try:
        pics = await photos.find_photos(wiki, wp.taxon, wp.image, wp.commons_category, wp.titles, langs, log,
                                        settings.knowledge_max_photos)
        manual = (file_data or {}).get("url") if not plantfile.photos_owned(file_data) else None
        credits = await photos.credits_for_urls(wiki, manual) if isinstance(manual, dict) else []
    except Exception as exc:                           # zdjecia nie moga zatrzymac zbierania wiedzy
        log(f"  zdjecia: blad ({str(exc)[:100]})")
        return 0
    with Session(engine) as s:
        row = s.get(Plant, plant_id)
        row.photos_json = json.dumps({"zdjecia": [p.as_dict() for p in pics], "autorzy": credits}, ensure_ascii=False)
        row.photos_at = datetime.now(timezone.utc)
        s.add(row)
        s.commit()
    if credits:
        log(f"  zdjecia: galeria reczna zostaje, opisano autorow i licencje {len(credits)} zdjec")
    else:
        log(f"  zdjecia z Wikipedii: {len(pics)}" + (f" ({', '.join(p.podpis for p in pics)})" if pics else ""))
    return len(pics) or len(credits)


async def photos_plant(plant_id: str, wiki: WikiClient, log) -> str:
    """Tylko zdjecia (bez LLM): Wikidata -> Commons -> kontrola -> zapis w istniejacym pliku rosliny."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if original is None:
        return "nofile"
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        name, latin = (plant.nazwa_pl, plant.nazwa_lat) if plant else (original.get("nazwa_pl"),
                                                                        original.get("nazwa_lat"))
    wp = await wiki.find_plant(latin, name)
    if not wp:
        log("  nie znaleziono gatunku w Wikidata")
        return "notfound"
    if plant is None:
        return "nothing"
    if not await collect_photos(plant_id, wp, wiki, log, original):
        return "nothing"
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        s.expunge(plant)
    pics, credits = _photos_of(plant)
    cand = plantfile.with_photos(copy.deepcopy(original), original, pics, credits)
    return _save_candidate(plant_id, original, cand, crlf, log, operation="zdjecia")


async def organize_plant(plant_id: str, log, llm=None) -> str:
    """Tylko uporzadkowanie wiedzy juz zapisanej w pliku rosliny (bez zbierania). Zwraca wynik."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if not original or not ((original.get("wiedza") or {}).get("fakty")):
        return "nothing"
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        name, latin = (plant.nazwa_pl, plant.nazwa_lat) if plant else (original.get("nazwa_pl") or plant_id,
                                                                        original.get("nazwa_lat"))
    cand = await _organized(copy.deepcopy(original), name, latin, llm, log)
    if settings.knowledge_auto_merge:
        cand = await _merged(cand, name, latin, llm, log)
    errors = _check(plant_id, original, cand, log)
    if errors:
        return _rejected(plant_id, original, cand, errors, "uporzadkowanie", log)
    gate.record_success(plant_id)
    backup = plantfile.write_plant(plants_dir, plant_id, cand, crlf, Path(settings.backups_dir) / "plants",
                                   "uporzadkowanie")
    log("  plik uporzadkowany" + (f" (kopia zapasowa: {backup.name})" if backup else ""))
    _after_write(plant_id, cand)
    return "organized"


async def merge_plant(plant_id: str, log, llm=None) -> str:
    """Tylko scalenie wiedzy z sieci (juz zapisanej w pliku) z rozdzialami i podrozdzialami strony."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if not original or not ((original.get("wiedza") or {}).get("fakty")):
        return "nothing"
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        name, latin = (plant.nazwa_pl, plant.nazwa_lat) if plant else (original.get("nazwa_pl") or plant_id,
                                                                        original.get("nazwa_lat"))
    cand = copy.deepcopy(original)
    if not cand["wiedza"].get("sekcje"):               # wiedza sprzed agregatora - najpierw uklad
        cand = await _organized(cand, name, latin, llm, log)
    cand = await _merged(cand, name, latin, llm, log)
    if cand == original:
        log("  bez zmian")
        update_coverage(plant_id, cand)
        return "nothing"
    errors = _check(plant_id, original, cand, log)
    if errors:
        return _rejected(plant_id, original, cand, errors, "scalenie z rozdzialami", log)
    gate.record_success(plant_id)
    backup = plantfile.write_plant(plants_dir, plant_id, cand, crlf, Path(settings.backups_dir) / "plants",
                                   "scalenie z rozdzialami")
    n = len((cand.get("scalone") or {}).get("pola") or {})
    log(f"  scalono z rozdzialami: {n} podrozdzialow" + (f" (kopia zapasowa: {backup.name})" if backup else ""))
    _after_write(plant_id, cand)
    return "merged"


async def place_plant(plant_id: str, log, llm=None, force: bool = False) -> str:
    """Tylko rozmieszczenie wiedzy z sieci w rozdzialach i podrozdzialach strony (bez ponownego scalania)."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if not original or not ((original.get("wiedza") or {}).get("sekcje")):
        return "nothing"
    with Session(engine) as s:
        plant = s.get(Plant, plant_id)
        name = plant.nazwa_pl if plant else (original.get("nazwa_pl") or plant_id)
    cand = await _placed(copy.deepcopy(original), name, llm, log, force=force)
    if cand == original:
        log("  bez zmian")
        return "nothing"
    errors = _check(plant_id, original, cand, log)
    if errors:
        return _rejected(plant_id, original, cand, errors, "rozmieszczenie wiedzy", log)
    gate.record_success(plant_id)
    backup = plantfile.write_plant(plants_dir, plant_id, cand, crlf, Path(settings.backups_dir) / "plants",
                                   "rozmieszczenie wiedzy")
    blk = cand.get("rozmieszczenie") or {}
    log(f"  rozmieszczono: {sum(len(w['punkty']) for w in blk.get('wstawki') or [])} informacji w "
        f"{len(blk.get('wstawki') or [])} miejscach" + (f" (kopia zapasowa: {backup.name})" if backup else ""))
    return "placed"


async def run_plant_place(job_id: int, runner: JobRunner, llm=None, plant_ids: list[str] | None = None,
                          force: bool = False) -> dict:
    """Rozmieszczenie wiedzy z sieci we wszystkich (albo wskazanych) plikach roslin."""
    log = lambda m: job_log(job_id, m)  # noqa: E731
    ids = list(plant_ids) if plant_ids else organized_plant_ids()
    out = {"placed": 0, "invalid": 0, "nothing": 0, "busy": 0}
    log(f"Pliki do rozmieszczenia: {len(ids)}" + ("" if llm else " (bez LLM - same reguly)")
        + (" - od nowa (takze bez zmian w punktach)" if force else ""))
    for n, pid in enumerate(ids, 1):
        if runner.should_stop(job_id):
            log("Zatrzymano")
            break
        if pid in _BUSY:
            log(f"[{n}/{len(ids)}] {pid} - opracowywana w innym zadaniu, pomijam")
            out["busy"] += 1
            continue
        if _gate_skip(pid, n, len(ids), log, out):
            continue
        activity.set(job_id, f"rozmieszczanie {n}/{len(ids)}", pid)
        log(f"[{n}/{len(ids)}] {pid}")
        _BUSY.add(pid)
        try:
            out[await place_plant(pid, log, llm, force)] += 1
            _checkpoint(job_id, pid)
        except AllModelsFailedError as exc:
            log(f"Limity modeli wyczerpane - przerywam ({str(exc)[:120]})")
            break
        finally:
            _BUSY.discard(pid)
        _progress(job_id, n, len(ids))
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    _save_stats(job_id, out)
    return out


def unmerge_plant(plant_id: str) -> bool:
    """Usuwa blok "scalone" (strona wraca do recznych tekstow; wiedza z sieci zostaje w swojej zakladce)."""
    plants_dir = Path(settings.kwiatownik_plants_dir)
    original, crlf = plantfile.read_plant(plants_dir, plant_id)
    if not original or "scalone" not in original:
        return False
    cand = copy.deepcopy(original)
    cand.pop("scalone")
    plantfile.write_plant(plants_dir, plant_id, cand, crlf, Path(settings.backups_dir) / "plants",
                          "cofniecie scalenia")
    update_coverage(plant_id, cand)
    return True


def organized_plant_ids() -> list[str]:
    """Rosliny, ktorych pliki maja wiedze z Siedziby (kandydaci do uporzadkowania)."""
    from app.knowledge.registry import kwiatownik_plants
    out = []
    for p in kwiatownik_plants(settings.kwiatownik_plants_dir):
        if p["origin"] == "archiwum":
            continue
        data, _ = plantfile.read_plant(settings.kwiatownik_plants_dir, p["id"])
        if data and (data.get("wiedza") or {}).get("fakty"):
            out.append(p["id"])
    return out


def _count(plant_id: str, status: str) -> int:
    with Session(engine) as s:
        return s.exec(select(func.count()).select_from(PlantFact).where(
            PlantFact.plant_id == plant_id, PlantFact.status == status)).one()


_VALUES: dict = {"at": 0.0, "key": None, "v": {}, "odd": set()}


def plant_values(max_age_s: float = 600.0) -> tuple[dict[str, float], set[str]]:
    """(wartosc rosliny dla czytelnikow, rosliny z plikiem w niestandardowym ukladzie) - etap 3 diagnostyki.
    Wartosc = odslony strony rosliny i jej rozdzialow z 60 dni (SiteStat) + 2 x liczba przepisow Kwiatownika, ktore
    ja wymieniaja. Plik bez "id" (stary uklad: gatunek, Cechy, Ogrodnictwo - jak swierzabek) zawsze wychodzil z niskim
    pokryciem i wracal do badan w kolko - takie rosliny czekaja na reczna poprawke pliku."""
    import time
    from app.exporters import store as xstore
    from app.models import SiteStat
    key = (str(settings.kwiatownik_przepisy_dir), str(settings.kwiatownik_plants_dir), str(engine.url))
    if _VALUES["key"] == key and time.time() - _VALUES["at"] < max_age_s:
        return _VALUES["v"], _VALUES["odd"]
    vals: dict[str, float] = {}
    since = (datetime.now(timezone.utc) - timedelta(days=60)).strftime("%Y-%m-%d")
    with Session(engine) as s:
        for kind, key, n in s.exec(select(SiteStat.kind, SiteStat.key, func.sum(SiteStat.n))
                                   .where(col(SiteStat.kind).in_(["plant_view", "plant_section"]),
                                          SiteStat.day >= since).group_by(SiteStat.kind, SiteStat.key)).all():
            pid = (key or "").split(":", 1)[0]
            if pid:
                vals[pid] = vals.get(pid, 0) + (n or 0) * (1.0 if kind == "plant_view" else 0.5)
    folder = Path(settings.kwiatownik_przepisy_dir)
    for f in xstore.current_files(folder) if folder.exists() else []:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            continue
        for r in data.get("przepisy", [data]) if isinstance(data, dict) else data:
            if not isinstance(r, dict) or r.get("wzmianka"):
                continue
            ids = {sk.get("link_id") for sk in r.get("skladniki") or [] if isinstance(sk, dict)}
            ids |= {r.get("roslina_id"), r.get("slug")}
            for pid in ids - {None, ""}:
                vals[str(pid)] = vals.get(str(pid), 0) + 2
    odd: set[str] = set()
    pdir = Path(settings.kwiatownik_plants_dir)
    for f in pdir.glob("*.json") if pdir.exists() else []:
        try:
            data = json.loads(f.read_text(encoding="utf-8-sig"))
        except (ValueError, OSError):
            continue
        if isinstance(data, dict) and "id" not in data and "gatunek" in data:
            odd.add(f.stem)
    _VALUES.update(at=time.time(), key=key, v=vals, odd=odd)
    return vals, odd


def plants_to_research(limit: int) -> list[str]:
    """Najpierw rosliny nigdy nie badane (najcenniejsze dla czytelnikow: odslony + przepisy, potem nowe z wieloma
    przepisami), potem te z najwiekszymi lukami w schemacie (najmniejsze pokrycie), na koncu najdawniej badane.
    Pomija rosliny na przerwie (malejacy zwrot) i z plikiem w niestandardowym ukladzie."""
    with Session(engine) as s:
        rows = s.exec(select(Plant)).all()
    vals, odd = plant_values()
    rows = [p for p in rows if p.id not in odd]
    never = sorted([p for p in rows if p.last_research_at is None],
                   key=lambda p: (-vals.get(p.id, 0), -(p.mentions or 0), p.nazwa_pl))
    rest = sorted([p for p in rows if p.last_research_at is not None],
                  key=lambda p: (p.coverage if p.coverage is not None else 0, p.last_research_at))
    stop = gate.blocked_map()
    return [p.id for p in never + rest if p.id not in _BUSY and p.id not in stop and not research_paused(p)][:limit]


async def run_plant_research(job_id: int, runner: JobRunner, llm, plant_ids: list[str] | None = None,
                             limit: int = 10, wiki: WikiClient | None = None, slots: list[str] | None = None,
                             respect_pause: bool = False) -> dict:
    """slots: szukaj tylko tych brakujacych podrozdzialow (np. ["zastosowanie.rzemieslnicze"]).
    respect_pause: zlecenia agentow pomijaja rosliny na przerwie po badaniach bez wynikow (reczne - nie)."""
    if llm is None:
        raise RuntimeError("Zbieranie wiedzy wymaga LLM - ustaw klucze GEMINI/GROQ w .env")
    log = lambda m: job_log(job_id, m)  # noqa: E731
    with Session(engine) as s:
        if not s.exec(select(func.count()).select_from(Plant)).one():
            sync_kwiatownik(s, settings.kwiatownik_plants_dir)
    ids = list(plant_ids) if plant_ids else plants_to_research(limit)
    own_wiki = wiki is None
    wiki = wiki or WikiClient(settings.user_agent)
    total = {"plants": 0, "sources": 0, "facts": 0, "verified": 0, "rejected": 0, "applied": 0, "waiting": 0,
             "invalid": 0}
    log(f"Rosliny do opracowania: {len(ids)}; jezyki Wikipedii: {settings.knowledge_languages} "
        f"(max {settings.knowledge_wiki_langs}), inne strony: {settings.knowledge_web_pages}")
    try:
        await translate_pending_facts(log, plant_ids=ids or None)
    except Exception as exc:  # noqa: BLE001 - tlumaczenie cytatow nie zatrzymuje badan
        log(f"Tlumaczenie cytatow wiedzy: blad ({str(exc)[:120]})")
    try:
        for n, pid in enumerate(ids, 1):
            if runner.should_stop(job_id):
                log("Zatrzymano")
                break
            with Session(engine) as s:
                plant = s.get(Plant, pid)
                title = plant.nazwa_pl if plant else pid
            if not plant:
                continue
            if pid in _BUSY:
                log(f"[{n}/{len(ids)}] {title} - opracowywana teraz w innym zadaniu, pomijam")
                continue
            if _gate_skip(pid, n, len(ids), log, total):
                continue
            pause = research_paused(plant) if respect_pause and not slots else None
            if pause:
                log(f"[{n}/{len(ids)}] {title} - ostatnie badania bez nowych informacji, nastepne po "
                    f"{pause.strftime('%Y-%m-%d')} - pomijam")
                total["paused"] = total.get("paused", 0) + 1
                _progress(job_id, n, len(ids))
                continue
            activity.set(job_id, f"roslina {n}/{len(ids)}", title)
            log(f"[{n}/{len(ids)}] {title}")
            _BUSY.add(pid)
            facts_before = facts_dump(pid)
            backlog = _count(pid, "new")
            verify_only = 0 < settings.knowledge_verify_first <= backlog
            if verify_only:
                # etap 3: wiedza zebrana wczesniej czeka na weryfikacje - najpierw ona, nowe badanie nastepnym razem
                log(f"  {backlog} informacji czeka na weryfikacje - najpierw weryfikacja, bez nowego zbierania")
            try:
                st = {"sources": 0, "facts": 0, "rejected_quotes": 0} if verify_only else \
                    await research_plant(pid, llm, wiki, log, job_id, slots=slots)
                vs = await verify_plant(pid, llm, log, job_id)
                _record_facts(pid, title, facts_before, "zbieranie i weryfikacja informacji")
                outcome = await apply_plant(pid, log, llm) if settings.knowledge_auto_apply else "nothing"
            except AllModelsFailedError as exc:
                _record_facts(pid, title, facts_before, "zbieranie informacji (przerwane - limity modeli)")
                log(f"Limity modeli wyczerpane - przerywam ({str(exc)[:120]}). Ponow zadanie pozniej "
                    "(zebrane informacje zostaja i zostana zweryfikowane przy nastepnym razie).")
                break
            except Exception as exc:  # noqa: BLE001 - blad jednej rosliny nie przerywa calego zadania
                logging.getLogger(__name__).exception("Zbieranie wiedzy: %s", pid)
                _record_facts(pid, title, facts_before, "zbieranie informacji (przerwane bledem)")
                _mark_error(pid, [f"{type(exc).__name__}: {exc}"[:300]])
                log(f"  BLAD przy tej roslinie ({type(exc).__name__}: {str(exc)[:160]}) - przechodze do nastepnej; "
                    "zebrane informacje zostaja w bazie")
                total["errors"] = total.get("errors", 0) + 1
                _progress(job_id, n, len(ids))
                continue
            finally:
                _BUSY.discard(pid)
            with Session(engine) as s:
                row = s.get(Plant, pid)
                row.last_research_at = datetime.now(timezone.utc)
                if row.status not in ("applied", "error"):
                    row.status = "researched"
                s.add(row)
                s.commit()
            nxt = note_yield(pid, st["facts"]) if not slots and not verify_only else None
            if nxt:
                log(f"  malo nowych informacji ({st['facts']}) - nastepne badanie tej rosliny po {nxt.strftime('%Y-%m-%d')}")
            total["plants"] += 1
            total["skipped_sources"] = total.get("skipped_sources", 0) + st.get("skipped", 0)
            for k in ("sources", "facts"):
                total[k] += st[k]
            for k in ("verified", "rejected"):
                total[k] += vs[k]
            if outcome in total:
                total[outcome] += 1
            _checkpoint(job_id, pid)
            _progress(job_id, n, len(ids))
    finally:
        if own_wiki:
            await wiki.aclose()
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in total.items()))
    _save_stats(job_id, total)
    return total


async def run_plant_apply(job_id: int, runner: JobRunner, llm=None, plant_ids: list[str] | None = None) -> dict:
    """Zapis zweryfikowanych informacji do plikow roslin (np. gdy KNOWLEDGE_AUTO_APPLY=false).
    Najpierw tlumaczenie cytatow (czekajace i dawne teksty LLM) - podmienione teksty trafiaja do plikow."""
    log = lambda m: job_log(job_id, m)  # noqa: E731
    try:
        await translate_pending_facts(log, plant_ids=plant_ids or None)
    except Exception as exc:  # noqa: BLE001
        log(f"Tlumaczenie cytatow wiedzy: blad ({str(exc)[:120]})")
    with Session(engine) as s:
        ids = plant_ids or list(s.exec(select(PlantFact.plant_id).where(PlantFact.status == "verified")
                                       .distinct()).all())
    out = {"applied": 0, "waiting": 0, "invalid": 0, "nothing": 0}
    for n, pid in enumerate(ids, 1):
        if runner.should_stop(job_id):
            log("Zatrzymano")
            break
        if _gate_skip(pid, n, len(ids), log, out):
            continue
        activity.set(job_id, f"zapis {n}/{len(ids)}", pid)
        log(pid)
        out[await apply_plant(pid, log, llm)] += 1
        _checkpoint(job_id, pid)
        _progress(job_id, n, len(ids))
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    _save_stats(job_id, out)
    return out


async def run_plant_photos(job_id: int, runner: JobRunner, llm=None, plant_ids: list[str] | None = None,
                           wiki: WikiClient | None = None) -> dict:
    """Zdjecia z Wikipedii dla roslin z plikami w Kwiatowniku (bez LLM - szybko)."""
    log = lambda m: job_log(job_id, m)  # noqa: E731
    from app.knowledge.registry import kwiatownik_plants
    with Session(engine) as s:
        sync_kwiatownik(s, settings.kwiatownik_plants_dir)
    ids = list(plant_ids) if plant_ids else [p["id"] for p in kwiatownik_plants(settings.kwiatownik_plants_dir)
                                             if p["origin"] != "archiwum"]
    own_wiki = wiki is None
    wiki = wiki or WikiClient(settings.user_agent)
    out = {"applied": 0, "nothing": 0, "invalid": 0, "notfound": 0, "nofile": 0, "error": 0}
    log(f"Zdjecia z Wikipedii dla {len(ids)} roslin (galerie wpisane recznie zostaja - dostaja opis autorow)")
    try:
        for n, pid in enumerate(ids, 1):
            if runner.should_stop(job_id):
                log("Zatrzymano")
                break
            if _gate_skip(pid, n, len(ids), log, out):
                continue
            activity.set(job_id, f"zdjecia {n}/{len(ids)}", pid)
            log(f"[{n}/{len(ids)}] {pid}")
            try:
                out[await photos_plant(pid, wiki, log)] += 1
            except Exception as exc:
                log(f"  [blad] {str(exc)[:120]}")
                out["error"] += 1
            _checkpoint(job_id, pid)
            _progress(job_id, n, len(ids))
    finally:
        if own_wiki:
            await wiki.aclose()
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    _save_stats(job_id, out)
    return out


async def run_plant_merge(job_id: int, runner: JobRunner, llm=None, plant_ids: list[str] | None = None) -> dict:
    """Scalanie wiedzy z sieci z rozdzialami plikow roslin (Bielik 11B -> Bielik 4.5B -> inne modele)."""
    from app.worker.ollama_pull import merge_models
    log = lambda m: job_log(job_id, m)  # noqa: E731
    ids = list(plant_ids) if plant_ids else organized_plant_ids()
    out = {"merged": 0, "invalid": 0, "nothing": 0, "busy": 0}
    log(f"Pliki do scalenia: {len(ids)}; modele scalania: {', '.join(merge_models()) or '-'}, potem zwykla lista"
        + ("" if llm else " (bez LLM - scalenie regulami)"))
    if llm is not None:
        from app.worker.ollama_pull import missing_ollama_models
        try:
            absent = set(await missing_ollama_models(llm))
        except Exception:
            absent = set()
        lacking = [m for m in merge_models() if m.startswith("ollama:") and m.split(":", 1)[1] in absent]
        if lacking:
            with Session(engine) as s:
                pulls = {j.kind.split(":", 1)[1]: j for j in s.exec(select(Job).where(
                    col(Job.kind).startswith("ollama_pull:"), col(Job.status).in_([JobStatus.queued, JobStatus.running]))).all()}
            for m in lacking:
                name = m.split(":", 1)[1]
                j = pulls.get(name)
                state = (f"pobiera sie teraz (zadanie #{j.id}: {j.progress or 0}/{j.total or '?'} MB)" if j else
                         "nie pobiera sie (tuz po starcie Siedziby pobieranie rusza samo po kilku sekundach; inaczej: "
                         "zakladka LLM, pole 'Pobierz model')")
                log(f"UWAGA: brak w Ollamie modelu scalania {name}: {state}")
            log("Do czasu pobrania scalaja modele z chmury (Gemini/Groq). Po pobraniu uruchom scalanie ponownie - "
                "podrozdzialy scalone w chmurze zostana poprawione Bielikiem.")
    for n, pid in enumerate(ids, 1):
        if runner.should_stop(job_id):
            log("Zatrzymano")
            break
        if pid in _BUSY:
            log(f"[{n}/{len(ids)}] {pid} - opracowywana w innym zadaniu, pomijam")
            out["busy"] += 1
            continue
        if _gate_skip(pid, n, len(ids), log, out):
            continue
        activity.set(job_id, f"scalanie {n}/{len(ids)}", pid)
        log(f"[{n}/{len(ids)}] {pid}")
        _BUSY.add(pid)
        try:
            out[await merge_plant(pid, log, llm)] += 1
            _checkpoint(job_id, pid)
        except AllModelsFailedError as exc:
            log(f"Limity modeli wyczerpane - przerywam ({str(exc)[:120]})")
            break
        finally:
            _BUSY.discard(pid)
        _progress(job_id, n, len(ids))
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    _save_stats(job_id, out)
    return out


async def run_plant_organize(job_id: int, runner: JobRunner, llm=None, plant_ids: list[str] | None = None) -> dict:
    """Agregator dla plikow, ktore juz maja wiedze (np. zebrana przed jego wprowadzeniem)."""
    log = lambda m: job_log(job_id, m)  # noqa: E731
    ids = list(plant_ids) if plant_ids else organized_plant_ids()
    out = {"organized": 0, "invalid": 0, "nothing": 0, "busy": 0}
    log(f"Pliki do uporzadkowania: {len(ids)}" + ("" if llm else " (bez LLM - uklad deterministyczny)"))
    for n, pid in enumerate(ids, 1):
        if runner.should_stop(job_id):
            log("Zatrzymano")
            break
        if pid in _BUSY:
            log(f"[{n}/{len(ids)}] {pid} - opracowywana w innym zadaniu, pomijam")
            out["busy"] += 1
            continue
        if _gate_skip(pid, n, len(ids), log, out):
            continue
        activity.set(job_id, f"porzadkowanie {n}/{len(ids)}", pid)
        log(f"[{n}/{len(ids)}] {pid}")
        _BUSY.add(pid)
        try:
            out[await organize_plant(pid, log, llm)] += 1
            _checkpoint(job_id, pid)
        finally:
            _BUSY.discard(pid)
        _progress(job_id, n, len(ids))
    log("Statystyki: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    _save_stats(job_id, out)
    return out
