import os
import json
import sys
import re
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from astro_engine import get_astrological_data
from data_builder import build_calendar_from_jsons, get_random_knowledge_pool, FESTIVAL_KNOWLEDGE
# FESTIVAL_KNOWLEDGE = FESTIVAL_KNOWLEDGE


def resource_path(relative_path):
    """ Zwraca absolutną ścieżkę do zasobu, działa dla dev i dla PyInstaller """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


app = Flask(__name__,
            template_folder=resource_path('templates'),
            static_folder=resource_path('static'))
app.config['SECRET_KEY'] = 'beka_has_lo'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///kwiatownik.db'
app.config['JSON_DATA_FOLDER'] = 'data/plants'

# Pobiera URL bazy z ustawień serwera, a jeśli go nie ma (lokalnie), używa SQLite
DATABASE_URL = os.getenv('DATABASE_URL')
# WAŻNE: Render/Neon często wymagają poprawki protokołu z postgres:// na postgresql://
if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL or 'sqlite:///local.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app, engine_options={
    "pool_pre_ping": True,
    "pool_recycle": 300,
})
login_manager = LoginManager(app)
login_manager.login_view = 'login'


# --- MODELE BAZY DANYCH (SQLITE) ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    comments = db.relationship('Comment', backref='author', lazy=True)


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, default=datetime.utcnow)
    is_private = db.Column(db.Boolean, default=False)
    plant_id = db.Column(db.String(100), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


with app.app_context():
    db.create_all()


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


@app.context_processor
def inject_astro():
    # 1. Sprawdzamy czy użytkownik użył już przycisku GPS (dane z ciasteczek)
    lat = request.cookies.get('user_lat')
    lon = request.cookies.get('user_lon')
    city_name = request.cookies.get('user_city')

    # 2. Jeśli nie ma ciasteczek, twardo ładujemy Czyżowice (ignorujemy IP!)
    if not lat or not lon:
        lat, lon = '49.95', '18.38'
        city_name = "Z"

    # 3. Pobieramy astro dla pewnych współrzędnych
    try:
        astro_data = get_astrological_data(lat=lat, lon=lon)
        astro_data['location'] = city_name
    except Exception as e:
        print(f"Błąd Astro: {e}")
        astro_data = {
            "location": city_name, "temp": "??°C", "humidity": "??%",
            "phase_name": "-", "festival": "Zwyczajny Czas",
            "festival_desc": "Brak danych", "festival_symbol": "-", "festival_action": "-",
            "numerology": "-", "japanese": "-", "element": "-"
        }

    return dict(astro=astro_data)


# --- FUNKCJE POMOCNICZE (JSON) ---
def normalize_slug(text):
    """Zamienia polskie znaki na ich odpowiedniki i przygotowuje bezpieczny slug."""
    accents = {
        'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n',
        'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z'
    }
    text = text.lower().replace(" ", "_")
    for char, replacement in accents.items():
        text = text.replace(char, replacement)
    return text


def get_plant_data(pid):
    # Zakładam, że Twoja ścieżka wygląda tak:
    slug = normalize_slug(pid)
    path = os.path.join('data', 'plants', f'{slug}.json')

    if not os.path.exists(path):
        print(f"BŁĄD: Plik {path} nie istnieje!")
        return None

    if os.path.getsize(path) == 0:
        print(f"BŁĄD: Plik {path} jest pustY (0 bajtów)!")
        return None

    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"BŁĄD: Plik {path} zawiera niepoprawny format JSON!")
        return None


def get_all_plants_list():
    """Zwraca listę wszystkich dostępnych roślin (nazwy plików)."""
    if not os.path.exists(app.config['JSON_DATA_FOLDER']):
        return []
    return [f.replace('.json', '') for f in os.listdir(app.config['JSON_DATA_FOLDER']) if f.endswith('.json')]


def get_all_recipes():
    all_recipes = []
    recipes_dir = os.path.join(app.root_path, 'data', 'przepisy')

    if os.path.exists(recipes_dir):
        for filename in os.listdir(recipes_dir):
            # Ładujemy wszystkie JSONy oprócz wzorca
            if filename.endswith('.json') and filename != 'wzorzec_przepisu.json':
                file_path = os.path.join(recipes_dir, filename)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        # Obsługa różnej struktury plików
                        if isinstance(data, dict) and "przepisy" in data:
                            all_recipes.extend(data["przepisy"])
                        elif isinstance(data, list):
                            all_recipes.extend(data)
                        else:
                            all_recipes.append(data)
                except Exception as e:
                    print(f"Błąd ładowania pliku {filename}: {e}")

    return all_recipes


import random


@app.route('/')
def index():
    # 1. Pobieranie podstawowych danych z plików JSON
    plants = get_all_plants_list()
    dynamic_calendar = build_calendar_from_jsons()
    recipes = get_all_recipes()

    # 2. Domyslna lokalizacja (Czyżowice) na wypadek awarii API
    lat, lon = '49.95', '18.38'
    city_name = "Z (Domyślnie)"

    # 3. Próba automatycznej lokalizacji przez GeoIP
    try:
        import requests
        # Korzystamy z darmowego API ip-api
        ip_resp = requests.get('http://ip-api.com/json/', timeout=2).json()
        if ip_resp and ip_resp.get('status') == 'success':
            lat = str(ip_resp.get('lat'))
            lon = str(ip_resp.get('lon'))
            city_name = ip_resp.get('city', 'Nieznana okolica')
    except Exception as e:
        print(f"Błąd GeoIP: {e}")

    # 4. Pobranie danych astrologicznych i pogodowych dla ustalonej lokalizacji
    astro = get_astrological_data(lat=lat, lon=lon)
    astro['location'] = city_name  # Nadpisujemy nazwę miasta tą z IP lub Nominatim

    # 5. INTELIGENTNY WYBÓR CIEKAWOSTEK (Knowledge Pool)
    # Pobieramy nazwę aktualnego święta (np. "Beltane / Zielone Świątki")
    current_fest = astro.get('festival', 'Zwyczajny Czas')

    # Wybieramy pulę wiedzy: dedykowaną dla święta + ogólną
    # Zakładamy, że FESTIVAL_KNOWLEDGE jest zdefiniowane w globalnym zakresie lub zaimportowane
    fest_pool = FESTIVAL_KNOWLEDGE.get(current_fest, [])
    general_pool = FESTIVAL_KNOWLEDGE.get("GENERAL", [])

    # Łączymy listy (jeśli święto ma swoje ciekawostki, będą na liście)
    full_knowledge_pool = fest_pool + general_pool

    # Mieszamy i wybieramy 10 losowych wpisów dla paska Marquee
    if full_knowledge_pool:
        knowledge = random.sample(full_knowledge_pool, min(len(full_knowledge_pool), 10))
    else:
        # Fallback, jeśli baza jest pusta
        knowledge = [{"roslina": "Kwiatownik", "tresc": "Wiedza o roślinach jest kluczem do zdrowia."}]

    # 6. Przygotowanie pełnych danych roślin do wyszukiwarki (Bestiariusz)
    full_data_list = []
    for plant_id in plants:
        plant_data = get_plant_data(plant_id)
        if plant_data:
            full_data_list.append(plant_data)

    # 7. Renderowanie strony głównej z kompletem danych
    return render_template(
        'index.html',
        plants=plants,
        plants_full_data=json.dumps(full_data_list),
        calendar_data=json.dumps(dynamic_calendar),
        astro=astro,
        knowledge=knowledge,
        recipes_full_data=json.dumps(recipes)
    )

@app.route('/plant/<plant_id>/')
def plant_detail(plant_id):
    plant_data = get_plant_data(plant_id)
    if not plant_data:
        abort(404)

    if current_user.is_authenticated:
        comments = Comment.query.filter(
            (Comment.plant_id == plant_id) &
            ((Comment.is_private == False) | (Comment.user_id == current_user.id))
        ).order_by(Comment.date_posted.desc()).all()
    else:
        comments = Comment.query.filter_by(plant_id=plant_id, is_private=False).order_by(
            Comment.date_posted.desc()).all()

    return render_template('plant_detail.html', plant=plant_data, plant_id=plant_id, comments=comments)


@app.route('/comments', methods=['GET', 'POST'])
def all_comments():
    """Podstrona ze wszystkimi komentarzami i dodawaniem ogólnych."""
    if request.method == 'POST':
        if not current_user.is_authenticated:
            flash('Zaloguj się, aby dodać komentarz.', 'warning')
            return redirect(url_for('login'))

        new_comment = Comment(
            content=request.form.get('content'),
            author=current_user,
            plant_id=None
        )
        db.session.add(new_comment)
        db.session.commit()
        return redirect(url_for('all_comments'))

    # --- NOWOŚĆ: Pobieranie danych dla paska Astro ---
    # Używamy tej samej logiki co w index(), aby pasek nie był pusty
    user_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if user_ip and ',' in user_ip:
        user_ip = user_ip.split(',')[0].strip()

    lat, lon = '49.95', '18.38'
    city_name = "Czyżowice (Domyślnie)"

    try:
        import requests
        url = f'http://ip-api.com/json/{user_ip}'
        ip_resp = requests.get(url, timeout=2).json()
        if ip_resp and ip_resp.get('status') == 'success':
            lat = str(ip_resp.get('lat'))
            lon = str(ip_resp.get('lon'))
            city_name = ip_resp.get('city', 'Nieznana okolica')
    except Exception:
        pass

    astro = get_astrological_data(lat=lat, lon=lon)
    astro['location'] = city_name
    # ------------------------------------------------

    comments = Comment.query.order_by(Comment.date_posted.desc()).all()

    # DODANO: astro=astro do render_template
    return render_template('all_comments.html', comments=comments, astro=astro)


# --- ZARZĄDZANIE KOMENTARZAMI (CRUD) ---

@app.route('/comment/add/<plant_id>', methods=['POST'])
@login_required
def add_comment(plant_id):
    content = request.form.get('content')

    is_private = True if request.form.get('is_private') else False

    if content:
        comment = Comment(
            content=content,
            plant_id=plant_id,
            author=current_user,
            is_private=is_private
        )
        db.session.add(comment)
        db.session.commit()
        if is_private:
            flash('Dodano prywatną notatkę.', 'info')
        else:
            flash('Dodano publiczny komentarz.', 'success')

    return redirect(url_for('plant_detail', plant_id=plant_id))


@app.route('/comment/edit/<int:comment_id>', methods=['GET', 'POST'])
@login_required
def edit_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    if comment.author != current_user and not current_user.is_admin:
        abort(403)

    if request.method == 'POST':
        comment.content = request.form.get('content')
        db.session.commit()
        flash('Komentarz zaktualizowany.', 'success')
        return redirect(url_for('all_comments'))

    return render_template('edit_comment.html', comment=comment)


@app.route('/comment/delete/<int:comment_id>')
@login_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    if comment.author != current_user and not current_user.is_admin:
        abort(403)

    db.session.delete(comment)
    db.session.commit()
    flash('Komentarz usunięty.', 'info')
    return redirect(request.referrer or url_for('all_comments'))


# --- GILDIE ---


@app.route('/gildie/', methods=['GET', 'POST'])
def gildie():
    # --- LOGIKA LOKALIZACJI (Kopiujemy to, co mamy w index i comments) ---
    user_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if user_ip and ',' in user_ip:
        user_ip = user_ip.split(',')[0].strip()

    lat, lon = '49.95', '18.38'
    city_name = "Z (Domyślnie)"

    try:
        import requests
        url = f'http://ip-api.com/json/{user_ip}'
        ip_resp = requests.get(url, timeout=2).json()
        if ip_resp and ip_resp.get('status') == 'success':
            lat = str(ip_resp.get('lat'))
            lon = str(ip_resp.get('lon'))
            city_name = ip_resp.get('city', 'Nieznana okolica')
    except Exception:
        pass

    astro = get_astrological_data(lat=lat, lon=lon)
    astro['location'] = city_name
    # ---------------------------------------------------------------------

    all_plants_ids = get_all_plants_list()
    all_plants_data = []

    for pid in all_plants_ids:
        data = get_plant_data(pid)
        if data:
            all_plants_data.append({'id': pid, 'name': data.get('nazwa_pl')})

    selected_plant = None
    companions = []

    if request.method == 'POST':
        plant_id = request.form.get('main_plant') or request.form.get('search_query')

        if plant_id and not get_plant_data(plant_id):
            for p in all_plants_data:
                if p['name'].lower() == plant_id.lower():
                    plant_id = p['id']
                    break

        selected_plant = get_plant_data(plant_id)

        if selected_plant:
            perma_data = selected_plant.get('permakultura', {})
            raw_companions = perma_data.get('gildie', [])

            if isinstance(raw_companions, list):
                for c in raw_companions:
                    base_name = c['nazwa'].split('(')[0].strip()
                    comp_id = next((p['id'] for p in all_plants_data if p['name'].lower() == base_name.lower()), None)

                    companions.append({
                        'nazwa': c['nazwa'],
                        'rola': c['rola'],
                        'id': comp_id
                    })

    # DODANO: astro=astro do render_template
    return render_template('gildie.html',
                           all_plants=all_plants_data,
                           selected_plant=selected_plant,
                           companions=companions,
                           astro=astro)


# --- SZUKAJ OBJAWU ---
def get_all_therapeutic_keywords():
    all_plants_ids = get_all_plants_list()
    keywords = set()

    for pid in all_plants_ids:
        data = get_plant_data(pid)

        # Sprawdzamy, czy dane w ogóle istnieją
        if not data:
            continue

        # --- KLUCZOWA POPRAWKA: Sprawdzenie typu danych ---
        if not isinstance(data, dict):
            print(f"!!! KRYTYCZNY BŁĄD: Plik '{pid}.json' ma zły format (jest LISTĄ zamiast OBIEKTEM).")
            continue

        try:
            # Bezpieczne pobieranie części rośliny
            czesci = data.get('czesci_rosliny', {})
            if isinstance(czesci, dict):
                for czesc in czesci.values():
                    if isinstance(czesc, dict):
                        wlasciwosci = czesc.get('wlasciwości', '')
                        words = [w.strip().lower() for w in wlasciwosci.replace(',', ' ').replace('.', ' ').split()]
                        keywords.update(words)

            # Bezpieczne pobieranie zastosowania
            zastosowanie = data.get('zastosowanie', {})
            if isinstance(zastosowanie, dict):
                medyczne = zastosowanie.get('medyczne', '')
                if isinstance(medyczne, str):
                    med_words = [w.strip().lower() for w in medyczne.replace(',', ' ').replace('.', ' ').split()]
                    keywords.update(med_words)
            else:
                # Jeśli 'zastosowanie' to np. tekst zamiast obiektu w JSON
                print(f"!!! OSTRZEŻENIE: Plik '{pid}.json' ma złą strukturę pola 'zastosowanie'.")

        except Exception as e:
            print(f"!!! BŁĄD podczas procesowania pliku '{pid}.json': {e}")
            continue

    # Filtrujemy zbyt krótkie słowa (poniżej 4 znaków)
    return sorted([word for word in keywords if len(word) > 3])


@app.route('/szukaj_terapeutyczna/', methods=['GET', 'POST'])
def szukaj_terapeutyczna():
    suggestions = get_all_therapeutic_keywords()  # Pobieramy słowa do autouzupełniania
    results = []
    query = ""

    if request.method == 'POST':
        query = request.form.get('query', '').lower()
        all_plants_ids = get_all_plants_list()

        for pid in all_plants_ids:
            data = get_plant_data(pid)
            if 'zastosowanie' not in data:
                print(f"UWAGA: Plik {pid}.json nie posiada sekcji zastosowanie!")

            full_text = str(data).lower()
            if query in full_text:
                results.append(data)

    return render_template('szukaj_terapeutyczna.html',
                           results=results,
                           query=query,
                           suggestions=suggestions)


# --- LOGIKA GENERATORA ---
@app.route('/generator/', methods=['GET', 'POST'])
def generator():
    # 1. Przygotowanie danych o roślinach i ich częściach
    all_plants_ids = get_all_plants_list()
    plants_data = []
    all_properties = set()

    for pid in all_plants_ids:
        data = get_plant_data(pid)
        if data and 'czesci_rosliny' in data:
            parts_info = {}

            # Pobieramy ostrzeżenie ogólne dla całej rośliny i czyścimy je
            raw_general_warn = data.get('ostrzezenia')
            general_warn_str = ""
            if isinstance(raw_general_warn, list):
                general_warn_str = " ".join(raw_general_warn)
            elif isinstance(raw_general_warn, str):
                general_warn_str = raw_general_warn

            for part_name, part_data in data['czesci_rosliny'].items():
                # A. Właściwości
                props_text = part_data.get('wlasciwości', '') or part_data.get('wlasciwosci', '')

                # B. Składniki aktywne
                ingr_raw = part_data.get('skladniki_aktywne', [])
                if isinstance(ingr_raw, list):
                    ingr_text = ", ".join(ingr_raw)
                else:
                    ingr_text = str(ingr_raw) if ingr_raw else ""

                # C. Ostrzeżenia dla części
                part_warn_raw = part_data.get('ostrzezenia')
                part_warn_str = ""

                if part_warn_raw:
                    # Jeśli część ma własne ostrzeżenie
                    if isinstance(part_warn_raw, list):
                        part_warn_str = " ".join(part_warn_raw)
                    else:
                        part_warn_str = str(part_warn_raw)
                else:
                    # Fallback: Jeśli część nie ma, bierzemy ogólne
                    part_warn_str = general_warn_str

                # D. Zapisujemy dane
                parts_info[part_name] = {
                    'props': props_text,
                    'ingr': ingr_text,
                    'warn': part_warn_str  # To zawsze jest teraz stringiem
                }

                if props_text:
                    words = [p.strip().lower() for p in props_text.replace(',', ' ').split() if len(p) > 3]
                    all_properties.update(words)

            plants_data.append({
                'slug': pid,
                'nazwa_pl': data.get('nazwa_pl', 'Nieznana'),
                'parts': parts_info,
                'warnings': general_warn_str  # Przekazujemy czysty string do atrybutu HTML
            })

    plants_data.sort(key=lambda x: x['nazwa_pl'])

    # 2. Obsługa komentarzy
    comments = Comment.query.filter_by(plant_id='generator').order_by(Comment.date_posted.desc()).all()

    if request.method == 'POST':
        if current_user.is_authenticated:
            content = request.form.get('content')
            is_private = request.form.get('is_private') == 'on'
            if content:
                new_comment = Comment(content=content, user_id=current_user.id, plant_id='generator',
                                      is_private=is_private)
                db.session.add(new_comment)
                db.session.commit()
                flash('Dodano notatkę do generatora.', 'success')
            return redirect(url_for('generator'))
        else:
            flash('Musisz być zalogowany, aby dodawać notatki.', 'danger')

    return render_template('generator.html', plants=plants_data, suggestions=sorted(list(all_properties)),
                           comments=comments)


# --- AUTENTYKACJA ---

@app.route('/register/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if User.query.filter_by(username=username).first():
            flash('Użytkownik już istnieje.', 'danger')
            return redirect(url_for('register'))

        hashed_pw = generate_password_hash(password)
        is_admin = True if User.query.count() == 0 else False

        new_user = User(username=username, password_hash=hashed_pw, is_admin=is_admin)
        db.session.add(new_user)
        db.session.commit()

        flash('Konto utworzone! Możesz się zalogować.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/login/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form.get('username')).first()
        if user and check_password_hash(user.password_hash, request.form.get('password')):
            login_user(user)
            return redirect(url_for('index'))
        flash('Błędny login lub hasło.', 'danger')
    return render_template('login.html')


@app.route('/logout/')
def logout():
    logout_user()
    return redirect(url_for('index'))


# Przepisy

@app.route('/przepisy/', methods=['GET'])
def przepisy():
    query = request.args.get('q', '').lower().strip()
    all_recipes = get_all_recipes()
    results = []

    if query:
        for recipe in all_recipes:
            # Wyciągamy nazwy składników, niezależnie czy to stare (stringi) czy nowe (słowniki)
            raw_skladniki = recipe.get('skladniki', [])
            ingredients_list = []
            for s in raw_skladniki:
                if isinstance(s, dict):
                    ingredients_list.append(s.get('nazwa', ''))
                elif isinstance(s, str):
                    ingredients_list.append(s)

            ingredients = " ".join(ingredients_list)

            # Zabezpieczenie starych i nowych pól (żeby nie wysypało się na listach obiektów)
            properties = " ".join([str(p) for p in recipe.get('wlasciwosci', []) if isinstance(p, str)])
            features = " ".join([str(f) for f in recipe.get('cechy', []) if isinstance(f, str)])

            searchable_text = (
                f"{recipe.get('tytul', '')} "
                f"{recipe.get('roslina', '')} "
                f"{ingredients} {properties} {features}"
            ).lower()

            if query in searchable_text:
                results.append(recipe)
    else:
        results = all_recipes

    return render_template('recipes.html', results=results, query=query)


@app.route('/api/recipe_suggestions')
def recipe_suggestions():
    """Zwraca listę pojedynczych słów kluczowych (bez śmieci i spójników)"""
    all_recipes = get_all_recipes()
    keywords = set()

    STOP_WORDS = {
        'w', 'z', 'i', 'o', 'a', 'do', 'na', 'po', 'ze', 'za', 'się', 'lub', 'jak',
        'ml', 'g', 'kg', 'dag', 'lyz', 'łyż', 'łyżka', 'łyżeczka', 'szklanki', 'szklanka',
        'proporcja', 'ok', 'szt', 'sztuk', 'litr', 'gram', 'często', 'bardzo', 'jest'
    }

    def clean_and_split(text):
        if not text:
            return []
        text = re.sub(r'[^\w\s]', '', str(text)) # Upewniamy się, że to string
        words = text.lower().split()
        return [w for w in words if len(w) > 2 and not w.isdigit() and w not in STOP_WORDS]

    for r in all_recipes:
        # Analizujemy składniki (teraz odporne na słowniki)
        for skladnik in r.get('skladniki', []):
            if isinstance(skladnik, dict):
                keywords.update(clean_and_split(skladnik.get('nazwa', '')))
            else:
                keywords.update(clean_and_split(skladnik))

        # Analizujemy pozostałe rzeczy
        for prop in r.get('wlasciwosci', []):
            if isinstance(prop, str):
                keywords.update(clean_and_split(prop))

        for cecha in r.get('cechy', []):
            if isinstance(cecha, str):
                keywords.update(clean_and_split(cecha))

        keywords.update(clean_and_split(r.get('roslina', '')))
        keywords.update(clean_and_split(r.get('tytul', '')))

    return jsonify(sorted(list(keywords)))


@app.route('/api/all_recipes.json')
def api_all_recipes():
    """Endpoint dla wersji statycznej - zwraca wszystkie przepisy w jednym pliku"""
    all_recipes = []

    # Ścieżki do plików z przepisami
    med_path = os.path.join('data', 'przepisy', 'przepisy_medyczne.json')
    kul_path = os.path.join('data', 'przepisy', 'przepisy_kulinarne.json')

    # Ładowanie medycznych
    if os.path.exists(med_path):
        with open(med_path, 'r', encoding='utf-8') as f:
            try:
                all_recipes.extend(json.load(f))
            except json.JSONDecodeError:
                pass

    # Ładowanie kulinarnych
    if os.path.exists(kul_path):
        with open(kul_path, 'r', encoding='utf-8') as f:
            try:
                all_recipes.extend(json.load(f))
            except json.JSONDecodeError:
                pass

    return jsonify(get_all_recipes())


@app.route('/api/all_plants.json')
def api_all_plants():
    """Endpoint dla wersji statycznej - zwraca całą bazę w jednym pliku"""
    all_plants_data = []

    # Zakładam, że get_all_plants_list() to Twoja funkcja zwracająca listę ID (np. ['wrotycz_pospolity', ...])
    for pid in get_all_plants_list():
        data = get_plant_data(pid)
        if data:
            data['slug'] = pid  # Dodajemy slug, żeby JavaScript wiedział, jak zbudować link do rośliny
            all_plants_data.append(data)

    return jsonify(all_plants_data)


if __name__ == '__main__':
    with app.app_context():
        if not os.path.exists(app.config['JSON_DATA_FOLDER']):
            os.makedirs(app.config['JSON_DATA_FOLDER'])

    app.run(debug=True)
